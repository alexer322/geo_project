import folium
import pandas as pd

data = pd.read_csv("data/znaki.txt")
lat = data['LAT']
lon = data['LON']
opis = data['ELEV']
icon_url = data['URL']

map = folium.Map(location=[37.296933,-121.9574983], zoom_start = 5)



for lat, lon, opis, icon_url in zip(lat, lon, opis, icon_url):
    icon = folium.CustomIcon("/home/pupa/workir/geo_proj/data/icon/"+icon_url+".png",
                                      icon_size=(50, 50))
    folium.Marker(location=[lat, lon], popup=str(opis)+" m", icon=icon).add_to(map)

# folium.Marker(location=[lat, lon], popup=str(elevation)+" m", icon=icon).add_to(map)


map.save("index.html")